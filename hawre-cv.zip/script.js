document.addEventListener("DOMContentLoaded", () => {
  // Set current year in footer
  document.getElementById("current-year").textContent = new Date().getFullYear()

  // Mobile menu toggle
  const menuToggle = document.getElementById("menu-toggle")
  const mobileMenu = document.getElementById("mobile-menu")

  menuToggle.addEventListener("click", () => {
    if (mobileMenu.classList.contains("hidden")) {
      mobileMenu.classList.remove("hidden")
    } else {
      mobileMenu.classList.add("hidden")
    }
  })

  // Language switcher
  const enBtn = document.getElementById("en-btn")
  const deBtn = document.getElementById("de-btn")
  const enElements = document.querySelectorAll(".lang-en")
  const deElements = document.querySelectorAll(".lang-de")

  function setLanguage(lang) {
    if (lang === "en") {
      enBtn.classList.remove("btn-secondary")
      enBtn.classList.add("btn-primary")
      deBtn.classList.remove("btn-primary")
      deBtn.classList.add("btn-secondary")

      enElements.forEach((el) => el.classList.remove("hidden"))
      deElements.forEach((el) => el.classList.add("hidden"))
    } else {
      deBtn.classList.remove("btn-secondary")
      deBtn.classList.add("btn-primary")
      enBtn.classList.remove("btn-primary")
      enBtn.classList.add("btn-secondary")

      deElements.forEach((el) => el.classList.remove("hidden"))
      enElements.forEach((el) => el.classList.add("hidden"))
    }
  }

  enBtn.addEventListener("click", () => {
    setLanguage("en")
  })

  deBtn.addEventListener("click", () => {
    setLanguage("de")
  })

  // Highlight active section on scroll
  const sections = document.querySelectorAll("section")
  const navLinks = document.querySelectorAll("nav a")

  function highlightNavOnScroll() {
    const scrollPosition = window.scrollY

    sections.forEach((section) => {
      const sectionTop = section.offsetTop - 100
      const sectionHeight = section.offsetHeight
      const sectionId = section.getAttribute("id")

      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        navLinks.forEach((link) => {
          link.classList.remove("btn-primary")
          link.classList.add("btn-secondary")

          if (link.getAttribute("href") === `#${sectionId}`) {
            link.classList.remove("btn-secondary")
            link.classList.add("btn-primary")
          }
        })
      }
    })
  }

  window.addEventListener("scroll", highlightNavOnScroll)
})
